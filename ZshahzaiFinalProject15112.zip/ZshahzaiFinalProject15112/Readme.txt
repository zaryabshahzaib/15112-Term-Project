Hey! Thanks for downloading guitar buddy.

You need the following libraries to run this program:

pygame
pyaudio
time
numpy
wave


Hope you enjoy the program!