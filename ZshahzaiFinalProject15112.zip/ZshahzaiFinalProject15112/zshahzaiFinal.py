# Code designed and written by: Zaryab Shahzaib
# Andrew ID: zshahzai
# File Created: November 05, 8:00am
# Modification History:
# Start End
# 05/11 6:00pm 05/11 11:45pm
# 09/11 8:30pm 09/11 11:15pm
# 10/11 04:00pm 10/11 7:00pm
# 15/11 8:00pm 15/11 11:38pm
# 20/11 4:00pm 20/11 11:15pm
# 22/11 06:00pm 22/11 7:00pm
# 23/11 8:00pm 23/11 11:20pm
# 24/11 4:00pm 24/11 5:30pm
# 25/11 03:00am 25/11 8:50am



#----IMPORT ALL THE REQUIRED LIBRARIES---#
import pygame
import pyaudio
import time
import numpy as np
import wave


#--- DEFINE SOME COLOURS THAT WE WILL USE IN THE PROGRAM---#
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)


#----INITIALIZE PYGAME---#
pygame.display.init()
pygame.font.init()
pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=4096)


#--SET SCREEN DIMENSIONS--#
screen = pygame.display.set_mode((500,420))
pygame.display.flip()


#--LOAD BACKGROUND IMAGE--#
bgimg = pygame.image.load("bg.gif").convert()
bgimg = pygame.transform.scale(bgimg, (500, 420))
rect = bgimg.get_rect()


 
#--SET THE WIDTH AND THE HEIGHT OF THE SCREEN--#
size = (500, 420)
screen = pygame.display.set_mode(size)
 
pygame.display.set_caption("Guitar Buddy")
 

#--LOOP UNTIL THE USER CLICKS ON THE CLOSE BUTTON--#.
done = False
 
#--THIS MANAGES HOW FAST THE SCREEN UPDATES--#
clock = pygame.time.Clock()


#--LOAD THE IMAGES REQUIRED FOR THE PROGRAM--#
bgimg = pygame.image.load("bg.gif").convert()
bgimg = pygame.transform.scale(bgimg, (500, 420))
rect = bgimg.get_rect()

bgimg2 = pygame.image.load("we.gif").convert()
bgimg2 = pygame.transform.scale(bgimg2, (500, 420))
rect2 = bgimg2.get_rect()

bgimg3 = pygame.image.load("aaa.gif").convert()
bgimg3 = pygame.transform.scale(bgimg3, (500, 420))
rect3 = bgimg3.get_rect()

#--LOAD THE FONTS THAT WILL BE USED IN THE PROGRAM--#
myfont = pygame.font.SysFont('Comic Sans MS', 25)
myfont3 = pygame.font.SysFont('Comic Sans MS', 35)
myBfont= pygame.font.SysFont('Comic Sans MS', 20)
myfontBB = pygame.font.SysFont('Comic Sans MS', 30)

#--EMPTY LIST TO HOLD CHORD BUTTON OBJECTS--#
Emlis=[]


#--INITIALIZE ALL THE PROGRAM WINDOWS--#
NextWin1 =False
ChordWin= False
TunerWin=False


#--LIST WITH CHORD NAMES--#
diction={"A":False,"Asharp":False,"Am":False,"B":False,"Bm":False,"C":False}


#--A FUNCTION TO MAKE AN INTERACTIVE CHORD BUTTON--#
# It takes coordinates and chord name as input and returns the rectangle object. 
def InteractiveChord(a,b,c,d,chord):
    A= pygame.Rect((a,b,c,d))
    Emlis.append(A)

    if a+c > mouse[0] > a and b+d> mouse[1] > b:
        area= pygame.draw.rect(screen,(175,175,175),(a,b,c,d))
    else:
        area = pygame.draw.rect(screen,(200,200,200),(a,b,c,d))
    fnt= pygame.font.SysFont('Comic Sans MS', 25)
    if len(chord) == 1:
        textsurfaceB1= fnt.render(chord, False, (0,0,0))
        screen.blit(textsurfaceB1,(a+15,b-2))
    else:
        textsurfaceB1= fnt.render(chord, False, (0,0,0))
        screen.blit(textsurfaceB1,(a+7,b-2))
    return area

#--A FUNCTION TO MAKE INTERACTIVE BUTTONS THAT CHANGE COLOUR UPON HOVER--#
def InteractiveButton(a,b,c,d):
    if a+c > mouse[0] > a and b+d> mouse[1] > b:
        area= pygame.draw.rect(screen,(175,175,175),(a,b,c,d))
    else:
        area = pygame.draw.rect(screen,(200,200,200),(a,b,c,d))
    return area



SoundPlayed={"A":0,"Asharp":0,"Am":0,"B":0,"Bm":0,"C":0,"cminor":0,"csharp":0,"D":0,"Dm":0,"Dsharp":0,"E":0,"F":0,"fsharp":0,"fminor":0,"G":0}

#--INITIALIZE VARIBALES THAT WILL BE USED LATER IN THE PROGRAM
TuneWind=False
RecWind=False
recording = False
recStop = False
frames = []
Paudio= False
StrumP = False

#--LOAD FILE FOR THE AUDIO RECORDING COMPONENT--#
playS =  pygame.mixer.Sound("file.wav")

# --------MAIN LOOP-----------#
while not done:
    #A List containing al the chords used in the program.
    ChordList=["A.gif","Asharp.gif","Am.gif","B.gif","bminor.gif","C.gif","cminor.gif","csharp.gif","D.gif","dm.gif","dsharp.gif","E.gif","F.gif","fsharp.gif","fminor.gif","G.gif"]
    L=[]
    for i in ChordList:
        Cchord= pygame.image.load(i).convert()
        Cchord= pygame.transform.scale(Cchord, (150, 150))
        L.append(Cchord)

    # --- Main event loop
    #--DEFINE THE INTERACTIVE BUTTON AREAS--#
    A2 = pygame.Rect((210,120,80,40))
    Gwind = pygame.Rect((210,170,80,40))
    BackButt = pygame.Rect((330,330,80,40))
    BackButt2 = pygame.Rect((310,330,80,40))
    Swind = pygame.Rect((210,220,80,40))
    recC = pygame.Rect((100,100,80,40))
    stopC = pygame.Rect((250,100,80,40))
    paudioC = pygame.Rect((375,100,80,40))
    FinalWind = pygame.Rect((210,270,90,40))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button.
                #Check if Left ouse button was clicked in any of these areas and do the appropriate actions.
                if area.collidepoint(event.pos):
                    NextWin1= True           
                if FinalWind.collidepoint(event.pos):
                    NextWin1=False
                    StrumP=True
                if A2.collidepoint(event.pos):
                    NextWin1=False
                    ChordWin=True
                if Swind.collidepoint(event.pos):
                    NextWin1=False
                    ChordWin=False
                    TuneWind= False
                    StrumP=False
                    RecWind=True
                if Gwind.collidepoint(event.pos):
                    NextWin1=False
                    ChordWin=False
                    RecWind = False
                    StrumP=False
                    TuneWind= True
                if BackButt.collidepoint(event.pos):
                    TuneWind= False
                    ChordWin=False
                    RecWind = False
                    StrumP=False
                    NextWin1=True
                if BackButt2.collidepoint(event.pos):
                    TuneWind= False
                    ChordWin=False
                    RecWin = False
                    StrumP=False
                    NextWin1=True
                if recC.collidepoint(event.pos):
                    recording = True
                if paudioC.collidepoint(event.pos):
                    Paudio = True                
                if stopC.collidepoint(event.pos):
                    recording = False
                    recStop=True
                #CHECK IF ONE OF THE CHORDS WAS CLICKED
                if Emlis != []:
                    indexDict={"A":0,"Asharp":1,"Am":2,"B":3,"Bm":4,"C":5,"cminor":6,"csharp":7,"D":8,"Dm":9,"Dsharp":10,"E":11,"F":12,"fsharp":13,"fminor":14,"G":15}
                    for i in range(0,16):
                        if Emlis[i].collidepoint(event.pos):
                            for j in diction:
                                diction[j]= False
                            diction[indexDict.keys()[indexDict.values().index(i)]]=True
                            SoundPlayed[indexDict.keys()[indexDict.values().index(i)]]=0
                            

                        
    #--MAIN PROGRAM WINDOWS--#
                            
    if StrumP: #STRUMING PATTERN COMPONENT 

        #--BLIT THE BACKGROUND AND SET UP THE SCREEN WITH TEXT--#
        screen.blit(bgimg3, rect3)
        HeadL = myfont3.render('Struming Patterns:', False, (255, 255, 255))
        screen.blit(HeadL,(20,20))
        HeadL = myBfont.render('U: Up Stroke', False, (255, 255, 255))
        screen.blit(HeadL,(10,150))
        HeadL = myBfont.render('D: Down Stroke', False, (255, 255, 255))
        screen.blit(HeadL,(10,200))

        #--Make boxes so the strumming patterns can be placed in them--#
        S1 = pygame.draw.rect(screen,(175,175,175),(170,85,222,41))
        S1 = pygame.draw.rect(screen,(175,175,175),(170,135,222,40))
        S1 = pygame.draw.rect(screen,(175,175,175),(170,185,222,40))
        S1 = pygame.draw.rect(screen,(175,175,175),(170,235,222,40))
        S1 = pygame.draw.rect(screen,(175,175,175),(170,285,222,40))


        #--Write the strumming patern details to the respecitve boxes--#
        S1c = myfont3.render(' D D U U DU', False, (255, 255, 255))
        screen.blit(S1c,(170,83))
        S2c = myfont3.render(' D D D D DU', False, (255, 255, 255))
        screen.blit(S2c,(170,133))
        S3c = myfont3.render('  D D U UDD', False, (255, 255, 255))
        screen.blit(S3c,(170,183))
        S4c = myfont3.render('D UUD UUDU', False, (255, 255, 255))
        screen.blit(S4c,(170,233))
        S5c = myfont3.render('   D UDU D', False, (255, 255, 255))
        screen.blit(S5c,(170,283))
        mouse= pygame.mouse.get_pos()
        backbutton3 = InteractiveButton(310,330,80,40)
        textsurfaceBackB2= myfontBB.render('Back', False, (0,0,0))
        screen.blit(textsurfaceBackB2,(315,330))
        #Update the screen
        pygame.display.update()


    elif RecWind: #Sound recorder window
        #--BLIT THE BACKGROUND AND SET UP THE SCREEN WITH TEXT AND BUTTONS--#
        screen.blit(bgimg3, rect3)
        HeadL = myfont3.render('Sound Recorder:', False, (255, 255, 255))
        screen.blit(HeadL,(30,35))
        mouse= pygame.mouse.get_pos()
        rec = InteractiveButton(75,100,80,40)
        stop = InteractiveButton(225,100,80,40)
        play = InteractiveButton(375,100,80,40)


        #--ADD TEXT TO THE RESPECTIVE BUTTONS--#
        textsurfacerec= myfontBB.render('REC', False, (0,0,0))
        screen.blit(textsurfacerec,(85,100))
        textsurfacestop= myfontBB.render('STOP', False, (0,0,0))
        screen.blit(textsurfacestop,(225,100))
        textsurfaceplay= myfontBB.render('PLAY', False, (0,0,0))
        screen.blit(textsurfaceplay,(375,100))
        Status = myfont3.render('Status:', False, (0,0,0))
        screen.blit(Status,(200,150))
        Stbutt = InteractiveButton(155,220,200,40)


        #SET PYAUDIO VARIABLE VALUES TO RECORD FROM THE MICROPHONE
        FORMAT = pyaudio.paInt16
        CHANNELS = 2
        RATE = 44100
        CHUNK = 1024 * 8
        WAVE_OUTPUT_FILENAME = "file.wav"

        p = pyaudio.PyAudio()

        stream = p.open(format=FORMAT, channels=CHANNELS,
                rate=RATE, input=True,
                frames_per_buffer=CHUNK)

        if Paudio: #If the play button clicked
            #Play the audio and chage the status in the status bar
            playS =  pygame.mixer.Sound("file.wav")
            CurrentSt = myfontBB.render('PLAYING', False, (255,255,255))
            screen.blit(CurrentSt,(215,220))
            pygame.mixer.Sound.play(playS)
            Paudio = False
        #If the record button is clicked then record the sound. The loop runs at least three times to make sure the chunk is fully extracted
        #from the input.
        for i in range(3):
            if recording:
                #Start Recording and change status in the bar.
                pygame.mixer.Sound.stop(playS)
                CurrentSt = myfontBB.render('RECORDING', False, (255,255,255))
                screen.blit(CurrentSt,(160,220))
                data = stream.read(CHUNK)
                frames.append(data)

            if recStop:
                #Stop Recording or Playing. If Frames is not empty it means something was recorded so it will save it to the local directory.
                pygame.mixer.Sound.stop(playS)
                CurrentSt = myfontBB.render('DONE', False, (255,255,255))
                screen.blit(CurrentSt,(215,220))

                if frames != []:
                    data = stream.read(CHUNK)
                    frames.append(data)
                    stream.stop_stream()
                    stream.close()
                    p.terminate()

                    waveFile = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
                    waveFile.setnchannels(CHANNELS)
                    waveFile.setsampwidth(p.get_sample_size(FORMAT))
                    waveFile.setframerate(RATE)
                    waveFile.writeframes(b''.join(frames))
                    waveFile.close()
                    frames = []
                    recStop= False
                recStop= False

        if not recording:
            #This sets the current status to idle.
                CurrentSt = myfontBB.render('IDLE', False, (255,255,255))
                screen.blit(CurrentSt,(215,220))

        #Make the Back button and update the screen.
        backbutton3 = InteractiveButton(310,330,80,40)
        textsurfaceBackB2= myfontBB.render('Back', False, (0,0,0))
        screen.blit(textsurfaceBackB2,(315,330))
        pygame.display.update()



    elif TuneWind: #The guitar tuner window.
        #--BLIT THE BACKGROUND AND SET UP THE SCREEN WITH TEXT AND BUTTONS--#
        mouse= pygame.mouse.get_pos()
        screen.blit(bgimg3, rect3)
        TUfont= pygame.font.SysFont('Comic Sans MS', 20)
        Tuneoutput= pygame.draw.rect(screen,(200,200,200),(20,150,300,50))
        HeadL = myfont3.render('Guitar Tuner:', False, (255, 255, 255))
        screen.blit(HeadL,(30,35))
        descp=myBfont.render('Note   +- Offset', False, (255, 255, 255))
        screen.blit(descp,(30,120))
        backbutton2 = InteractiveButton(310,330,80,40)
        textsurfaceBackB2= myfontBB.render('Back', False, (0,0,0))
        screen.blit(textsurfaceBackB2,(315,330))
        

        p = pyaudio.PyAudio()
        MaxOffs = 20 #The value to store the maximum +- offset from the note frequency.

        #A dictionary to hold all the string freqencies 
        NOTE_FREQUENCIES = {
            "E2": 82.41,
            "A2": 110.00,
            "D3": 146.83,
            "G3": 196.00,
            "B3": 246.94,
            "E4": 329.63,
        }

        #SET PYAUDIO VARIABLES TO GET AUIDO FROM THE MICROPHONE 
        CHUNK = 1024 * 4
        FORMAT = pyaudio.paInt16
        CHANNELS = 1
        RATE = 41000
        WINDOW = np.blackman(CHUNK)
        SAMPLE_WIDTH = p.get_sample_size(FORMAT)
        #Initialize the Stream
        stream = p.open(format = FORMAT,
        channels = CHANNELS,
        rate = RATE,
        input = True,
        output = True,
        frames_per_buffer = CHUNK)

        #--MAIN TUNER LOOP--#
        #Real Time Microphone Analysis, https://gist.github.com/denisb411/cbe1dce9bc01e770fa8718e4f0dc7367
        for i in range(1):
            data = stream.read(CHUNK)
            newArray = np.array(wave.struct.unpack("%dh"%(len(data)/SAMPLE_WIDTH),data))*WINDOW #Convert the data into a numpy array and apply the blackman window funcitonfor smoothing values.
            fftData=abs(np.fft.rfft(newArray))**2 #Apply the Fast Fourier Transform Algorithm to convert the signal from the original domain to the frequency domain.

            MaxPeak = fftData[1:].argmax() + 1 #Find the maximum real value in the frequency domain.

            #Then use quadratic interpolation around the maximum real Frequency Value
            if MaxPeak != len(fftData)-1:
                y0,y1,y2 = np.log(fftData[MaxPeak-1:MaxPeak+2:])
                x1 = (y2 - y0) * .5 / (2 * y1 - y2 - y0)
                thefreq = (MaxPeak+x1)*RATE/CHUNK
            else:
                thefreq = MaxPeak*RATE/CHUNK

            for k,v in NOTE_FREQUENCIES.items():
                if (v + MaxOffs) >= float(thefreq/2.0) and (v - MaxOffs) <= float(thefreq/2.0): #If the frequency +- MaxOffset matches a value in the dictionary then output it. 
                    if (v-thefreq/2.0)/5> 0:
                        off = "+" + str((round(v-thefreq/2.0)/5))
                    else:
                        off = str((round(v-thefreq/2.0)/5))
                    a= "The note is: " + k + " " + off
                    textsurfaceTU= TUfont.render(a, False, (0,0,0))
                    screen.blit(textsurfaceTU,(30,160))
            #Update the Display
            pygame.display.update()

    elif ChordWin: #The Learn Chords Window
        #--BLIT THE BACKGROUND AND SET UP THE SCREEN WITH TEXT AND BUTTONS--#
        screen.blit(bgimg3, rect3)
        mouse= pygame.mouse.get_pos()
        Ac= InteractiveChord(20,100,50,30,"A")
        Asharpc= InteractiveChord(80,100,50,30,"A#")
        Amc= InteractiveChord(140,100,50,30,"Am")
        Bc= InteractiveChord(20,140,50,30,"B")
        Bminorc= InteractiveChord(80,140,50,30,"Bm")
        Cc= InteractiveChord(140,140,50,30,"C")
        Cminorc= InteractiveChord(20,180,50,30,"Cm")
        Csharpc= InteractiveChord(80,180,50,30,"C#")
        Dc= InteractiveChord(140,180,50,30,"D")
        Dminorc= InteractiveChord(20,220,50,30,"Dm")
        Csharpminorc= InteractiveChord(80,220,50,30,"D#")
        Dc= InteractiveChord(80,220,50,30,"E")
        Fc= InteractiveChord(140,220,50,30,"F")
        Fsharpc= InteractiveChord(20,260,50,30,"F#")
        Fminorc= InteractiveChord(80,260,50,30,"Fm")
        Gc= InteractiveChord(140,260,50,30,"G")
        indexDict={"A":0,"Asharp":1,"Am":2,"B":3,"Bm":4,"C":5,"cminor":6,"csharp":7,"D":8,"Dm":9,"Dsharp":10,"E":11,"F":12,"fsharp":13,"fminor":14,"G":15}
        backbutton = InteractiveButton(330,330,80,40)
        textsurfaceBackB= myfontBB.render('Back', False, (0,0,0))
        screen.blit(textsurfaceBackB,(335,330))

        #If the chord is true then play the chord.
        for i in diction:
            if diction[i] == True:
                screen.blit(L[indexDict[i]],(270,140))
                if SoundPlayed[indexDict.keys()[indexDict.values().index(indexDict[i])]] == 0:
                    ChordSound =  pygame.mixer.Sound(indexDict.keys()[indexDict.values().index(indexDict[i])]+".wav")
                    pygame.mixer.Sound.play(ChordSound)
                    SoundPlayed[indexDict.keys()[indexDict.values().index(indexDict[i])]]+=1
                    

        #--ADD TEXT TO THE SCREEN AND UPDATE--#
        textsurf = myfont3.render('Chords:', False, (255, 255, 255))
        screen.blit(textsurf,(50,35))
        textsurf1 = myfont3.render('Diagram:', False, (255, 255, 255))
        screen.blit(textsurf1,(270,35))
        pygame.display.update()

    elif NextWin1:
        #Main Window
        
        myB1font= pygame.font.SysFont('Comic Sans MS', 13)
        screen.blit(bgimg2, rect2)
        textsurface = myfont3.render('Pick a Module:', False, (255, 255, 255))
        screen.blit(textsurface,(135,35))
        mouse= pygame.mouse.get_pos()

        #Make all the buttons
        area1= InteractiveButton(210,120,90,40)
        area2= InteractiveButton(210,170,90,40)
        area3= InteractiveButton(210,220,90,40)
        area4= InteractiveButton(210,270,90,40)
        #Add text to the buttons
        textsurfaceB1= myB1font.render(' Learn Chords', False, (0,0,0))
        textsurfaceB2= myB1font.render('  Guitar Tuner', False, (0,0,0))
        textsurfaceB3= myB1font.render('  Rec Sound', False, (0,0,0))
        textsurfaceB4= myB1font.render('Strum Pattern', False, (0,0,0))
        #Blit text to screen
        screen.blit(textsurfaceB1,(210,130))
        screen.blit(textsurfaceB2,(210,180))
        screen.blit(textsurfaceB3,(210,230))
        screen.blit(textsurfaceB4,(210,280))


        
        pygame.display.update()


    else:
        #Add Background Image
        screen.blit(bgimg, rect)

        #WELCOME TEXT AND BUTTON TO ENTER

        textsurface = myfont.render('Welcome To Guitar Buddy', False, (0, 0, 0))
        textsurface2= myBfont.render('ENTER', False, (0, 0, 0))
        mouse= pygame.mouse.get_pos()
        area = InteractiveButton(300,200,80,56)

        screen.blit(textsurface,(175,35))
        screen.blit(textsurface2,(309,210))
     
     
        # Update the screen with what we've drawn.
        pygame.display.flip()
     
        # --- Limit to 30 frames per second
        clock.tick(30)
     
# Close the window and quit.
pygame.quit()
